# Date: 06/02/2018
# Author: Pure-L0G1C
# Description: __init__