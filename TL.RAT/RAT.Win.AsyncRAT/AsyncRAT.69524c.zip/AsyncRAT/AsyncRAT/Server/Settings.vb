﻿Public Class Settings
    Public Shared Ports As New List(Of Integer)
    Public Shared KEY As String = "<AsyncRAT123>"
    Public Shared ReadOnly VER As String = "AsyncRAT v1.8"
    Public Shared Online As New List(Of Client)
End Class
