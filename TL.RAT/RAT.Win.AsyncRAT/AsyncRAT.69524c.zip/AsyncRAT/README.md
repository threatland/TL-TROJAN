<img src="https://i.imgur.com/ltZNLZl.gif">


# AsyncRAT
	
***Remote Administration Tool For Windows***
 ```
This project is for learing, If you find any bug please contact me.
 ```

---


## Socket Features

- **Stable Connection**
- **Asynchronous Socket**
- **Multi-Hosts**
- **Multi-Ports**
- **Multi-Clients**
- **Encrypted Traffic**


---


## Author

* **NYAN CAT**  


---


## Download

* **https://github.com/NYAN-x-CAT/AsyncRAT/releases**  


---


## Disclaimer

I, the creator, am not responsible for any actions, and or damages, caused by this software.

You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only.

This software's main purpose is NOT to be used maliciously, or on any system that you do not own, or have the right to use.

By using this software, you automatically agree to the above.


---


## License
[![License](http://img.shields.io/:license-mit-blue.svg?style=flat-square)](/LICENSE)

This project is licensed under the MIT License - see the [LICENSE](/LICENSE) file for details