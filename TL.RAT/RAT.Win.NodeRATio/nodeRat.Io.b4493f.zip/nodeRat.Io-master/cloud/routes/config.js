// =================================================== \\
// ================MYSQL/SOCKET CONFIG================ \\
// =================================================== \\
config_mysql_host 		= "localhost";
config_mysql_user 		= "root";
config_mysql_pswd 		= "";
config_mysql_db 		  = "noderatio";
config_ip_server      = "127.0.0.1";
config_port_server    = 8080;
